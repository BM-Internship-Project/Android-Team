package com.example.speedotransferapp.api

class FeatureAPICallable {
}
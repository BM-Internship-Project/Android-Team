package com.example.speedotransferapp.model

data class Profile(
    val name: String,
    val initials: String
)
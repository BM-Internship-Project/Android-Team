package com.example.speedotransferapp.ui_model
data class Profile(
    val name: String,
    val initials: String
)
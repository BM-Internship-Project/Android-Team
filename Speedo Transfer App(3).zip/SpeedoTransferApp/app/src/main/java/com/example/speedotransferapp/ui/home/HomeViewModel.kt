package com.example.speedotransferapp.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.speedotransferapp.data.BalanceSource
import com.example.speedotransferapp.data.ProfileSource
import com.example.speedotransferapp.data.TransactionsSource
import com.example.speedotransferapp.mapper.BalanceMapper
import com.example.speedotransferapp.model.Balance
import com.example.speedotransferapp.model.TransactionItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch


class HomeViewModel : ViewModel() {

    private val _transactions = MutableStateFlow<List<TransactionItem>>(emptyList())
    val transactions: StateFlow<List<TransactionItem>> = _transactions.asStateFlow()

    val profile = ProfileSource().getProfile()

    init {
        viewModelScope.launch {
            _transactions.value = TransactionsSource().getTransactions()
        }
    }

    fun getInitials(): String{
        val names = profile.initials.split(" ")
        val initials = names.map { it.first() }.joinToString("")
        return initials
    }
    fun getBalance(): Int {
        val balanceSource = BalanceSource()
        val balance: Balance = BalanceMapper.mapFromSource(balanceSource)
        return balance.balance
    }
}
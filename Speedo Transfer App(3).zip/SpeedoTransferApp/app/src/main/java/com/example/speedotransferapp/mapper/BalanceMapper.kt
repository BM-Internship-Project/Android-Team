package com.example.speedotransferapp.mapper

import com.example.speedotransferapp.data.BalanceSource
import com.example.speedotransferapp.model.Balance

object BalanceMapper {
    fun mapFromSource(source: BalanceSource): Balance {
        // Here you can access the data from BalanceSource
        // and map it to the Balance model as needed.
        return source.getBalance()
    }
}
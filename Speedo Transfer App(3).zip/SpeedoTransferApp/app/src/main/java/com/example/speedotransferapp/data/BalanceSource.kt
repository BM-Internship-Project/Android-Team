package com.example.speedotransferapp.data

import com.example.speedotransferapp.model.Balance

class BalanceSource {
    fun getBalance(): Balance {
        return Balance(
            "Available",
             200000)
    }
}


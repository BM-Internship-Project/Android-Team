package com.example.speedotransferapp.constant

object AppConstants {
    const val NUMBER = 1234
    const val EMAIL = "help@speedo.com"
    const val FAILED = "Failed"
    const val BEARER = "Bearer "

    const val BASE_URL = "https://speedotransfer1-506cf0850222.herokuapp.com"

    const val TRANSACTIONS_ENDPOINT = "/api/transactions"
    const val TRANSACTION_DETAILS_ENDPOINT = "/api/transactions/{transactionId}"
    const val REGISTER_ENDPOINT = "/api/auth/register"
    const val LOGIN_ENDPOINT = "/api/auth/login"
    const val LOGOUT_ENDPOINT = "/api/auth/logout"
    const val BALANCE_ENDPOINT = "/api/balance"
    const val NAME_ENDPOINT = "/api/name"
}
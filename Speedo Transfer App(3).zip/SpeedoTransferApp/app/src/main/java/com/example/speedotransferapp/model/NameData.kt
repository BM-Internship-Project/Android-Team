package com.example.speedotransferapp.model

data class NameData(
    val firstName: String,
    val lastName: String
)
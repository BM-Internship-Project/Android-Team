package com.example.speedotransferapp.api
import retrofit2.Retrofit
import com.example.speedotransferapp.constant.AppConstants.BASE_URL
import com.example.speedotransferapp.mock.UserInterceptor
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor


object RetrofitClient {

    private const val BASE_URL = "https://money-transfer-production.up.railway.app/"

    object UserAPIService {

        private val client: OkHttpClient = OkHttpClient.Builder()
            .addInterceptor(UserInterceptor()) // Add the interceptor
            .build()

        private val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client) //remove later
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val callable: UserAPICallable by lazy {
            retrofit.create(UserAPICallable::class.java)
        }
    }
}
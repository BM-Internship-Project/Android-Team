package com.example.speedotransferapp.model

data class Balance(
    val status: String,
    val balance: Int
)